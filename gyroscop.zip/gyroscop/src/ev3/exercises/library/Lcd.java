package ev3.exercises.library;

public class Lcd {

	public static void clear(int i) {
		// TODO Auto-generated method stub
		
	}

	public static void print(int i, String string, int angle, float angularVelocity) {
		// TODO Auto-generated method stub
		
	}

}
